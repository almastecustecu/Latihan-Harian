# latihanedit
